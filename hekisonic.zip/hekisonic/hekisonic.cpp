#include<hekisonic.h>
long send(int trigger, int echo)  {
    digitalWrite(trigger, HIGH);
    delayMicroseconds(10);
    digitalWrite(trigger, LOW);
    long time = pulseIn(echo, HIGH);
    return time;
}
Hekisonic::Hekisonic(int echoPin, int triggerPin) {
    echo = echoPin;
    trigger = triggerPin;
    pinMode(echo, INPUT);
    pinMode(trigger, OUTPUT);
}
void Hekisonic::set_temprature(int t) {
    temprature = t;
}
float Hekisonic::distance() {
    long time = send(trigger, echo);
    float v = 331.3 + 0.6 * temprature;
    float distance = (time * v) / 20000.0;
    return distance;
}
float Hekisonic::distance_mm() {
    return distance() * 10.0;
}
float Hekisonic::distance_um() {
    return distance_mm() * 1000.0;
}


