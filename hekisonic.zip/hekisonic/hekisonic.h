#ifndef hekisonic_h
#define hekisonic_h
#include <Arduino.h>
class Hekisonic {
    public:
        Hekisonic(int echoPin, int triggerPin);
        void set_temprature(int t);
        float distance();
        float distance_mm();
        float distance_um();
        float distance_nm();
    private:
        int echo;
        int trigger;
        int temprature = 20;
};
#endif